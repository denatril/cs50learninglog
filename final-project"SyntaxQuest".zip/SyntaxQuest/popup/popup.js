// /popup/popup.js  — FREE MODE VERSION

let currentPuzzle = null;
let currentDifficulty = "easy";

// Hint & solution state
let currentHintIndex = 0;
let hintUsed = false;
let solutionShown = false;

// ---------- ACHIEVEMENTS ----------
function loadAchievements() {
  return sqLoad("achievements", {});
}

function saveAchievements(obj) {
  sqSave("achievements", obj);
}

function showAchievementToast(msg) {
  const el = document.createElement("div");
  el.className = "achievementToast";
  el.textContent = "🏆 " + msg;
  document.body.appendChild(el);

  setTimeout(() => {
    el.style.opacity = "0";
    setTimeout(() => el.remove(), 1000);
  }, 2000);
}

function handleAchievements(puzzle) {
  const level = sqGetLevel();
  let achievements = loadAchievements();
  let unlocked = [];

  if (!achievements.firstSolve) {
    achievements.firstSolve = true;
    unlocked.push("First Puzzle Solved!");
  }
  if (puzzle.difficulty === "hard" && !achievements.firstHard) {
    achievements.firstHard = true;
    unlocked.push("Hard Master!");
  }
  if (puzzle.difficulty === "expert" && !achievements.firstExpert) {
    achievements.firstExpert = true;
    unlocked.push("Expert Slayer!");
  }
  if (level >= 10 && !achievements.level10) {
    achievements.level10 = true;
    unlocked.push("Reached Level 10!");
  }
  if (level >= 20 && !achievements.level20) {
    achievements.level20 = true;
    unlocked.push("Reached Level 20!");
  }

  saveAchievements(achievements);

  unlocked.forEach(showAchievementToast);
}

// ---------- MAIN ----------
const HINT_LIMITS = {
  easy: 7,
  hard: 4,
  expert: 2
};


document.addEventListener("DOMContentLoaded", () => {
  
  const xpEl = document.getElementById("xp");
  const levelEl = document.getElementById("level");
  const resetBtn = document.getElementById("resetBtn");

  const titleEl = document.getElementById("puzzleTitle");
  const descEl = document.getElementById("puzzleDesc");
  const answerInput = document.getElementById("answerInput");
  const checkBtn = document.getElementById("checkAnswerBtn");
  const resultEl = document.getElementById("resultMessage");

   const difficultySelect = document.getElementById("difficultySelect");
   
   const newPuzzleBtn = document.getElementById("newPuzzleBtn");

  const hintBtn = document.getElementById("hintBtn");
  const showSolutionBtn = document.getElementById("showSolutionBtn");
  const hintTextEl = document.getElementById("hintText");
  const solutionTextEl = document.getElementById("solutionText");

  // ---------- XP & LEVEL ----------
  function renderXpAndLevel() {
    xpEl.textContent = sqGetXp();
    levelEl.textContent = sqGetLevel();
  }

  function initProgress() {
    sqInitXp();
    sqInitLevel();
    sqRecomputeLevelFromXp();
    renderXpAndLevel();
  }

  // ---------- PUZZLE GENERATION (FREE MODE) ----------
   function generateNewPuzzle() {
     // Collect puzzles from all categories
     const allPuzzles = Object.values(sqPuzzlePacks).flat();
     if (!allPuzzles || allPuzzles.length === 0) {
       resultEl.textContent = "No puzzles available.";
       return;
     }

     const candidates = allPuzzles.filter((p) => p.difficulty === currentDifficulty);
     if (candidates.length === 0) {
       resultEl.textContent = "No puzzles match difficulty.";
       return;
     }

    let lastId = currentPuzzle ? currentPuzzle.id : null;

    let puzzle;
    if (candidates.length === 1) {
      puzzle = candidates[0];
    } else {
      do {
        puzzle = candidates[Math.floor(Math.random() * candidates.length)];
      } while (puzzle.id === lastId);
    }

    currentPuzzle = puzzle;

    // reset hint / solution states
    currentHintIndex = 0;
    hintUsed = false;
    solutionShown = false;
    hintTextEl.textContent = "";
    solutionTextEl.textContent = "";
    showSolutionBtn.disabled = false;

    renderPuzzle();
  }

  // ---------- RENDER PUZZLE ----------
  function renderPuzzle() {
    if (!currentPuzzle) return;

    titleEl.textContent = currentPuzzle.title;
    descEl.textContent = currentPuzzle.description;
    answerInput.value = "";
    resultEl.textContent = "";
  }

  // ---------- DIFFICULTY LOCKS ----------
  function getUnlockState() {
    const level = sqGetLevel();
    return {
      easy: true,
      hard: level >= 10,
      expert: level >= 20,
    };
  }

  function updateDifficultyUI() {
    const state = getUnlockState();
    const opts = difficultySelect.options;

    for (let i = 0; i < opts.length; i++) {
      const opt = opts[i];
      opt.disabled = !state[opt.value];
    }

    difficultySelect.value = currentDifficulty;
  }



  // ---------- CHECK ANSWER ----------
  function addXpWithHintPenalty(puzzle, hintUsed, solutionShown) {
    if (solutionShown) return;
    if (!hintUsed) {
      sqAddXpForDifficulty(puzzle.difficulty);
    } else {
      const base = { easy: 5, hard: 10, expert: 20 }[puzzle.difficulty] || 0;
      if (base > 0) sqAddXp(base / 2);
    }
  }

  function handleCheckAnswer() {
    if (!currentPuzzle) return;

    const isCorrect = sqCheckAnswer(
      currentPuzzle.expectedSolution,
      answerInput.value
    );

    if (isCorrect) {
      addXpWithHintPenalty(currentPuzzle, hintUsed, solutionShown);
      sqRecomputeLevelFromXp();
      renderXpAndLevel();
      updateDifficultyUI();

      handleAchievements(currentPuzzle);

      let msg = "Correct!";
      if (solutionShown) msg += " (No XP, solution viewed)";
      else if (hintUsed) msg += " Half XP (hint used)";
      resultEl.textContent = msg;
    } else {
      resultEl.textContent = "Incorrect. Try again.";
    }
  }

  // ---------- RESET ----------
  function resetProgress() {
    sqResetXp();
    sqSetLevel(1);
    sqRecomputeLevelFromXp();
    renderXpAndLevel();

     currentDifficulty = "easy";

     updateDifficultyUI();

    generateNewPuzzle();
    resultEl.textContent = "Progress reset.";
  }

   // ---------- EVENT LISTENERS ----------
   initProgress();
   updateDifficultyUI();

  generateNewPuzzle(); // FREE MODE → always start with fresh puzzle

  checkBtn.addEventListener("click", handleCheckAnswer);

  newPuzzleBtn.addEventListener("click", () => {
    generateNewPuzzle();
  });

   difficultySelect.addEventListener("change", () => {
     currentDifficulty = difficultySelect.value;
     generateNewPuzzle();
   });

  hintBtn.addEventListener("click", () => {
  if (!currentPuzzle || !currentPuzzle.hints) return;

  const maxHints = HINT_LIMITS[currentPuzzle.difficulty] || 1;

  // Eğer puzzle yeterli hint içermiyorsa, puzzle’ın kendi hints sayısını baz alıyoruz:
  const availableHints = Math.min(currentPuzzle.hints.length, maxHints);

  if (currentHintIndex < availableHints) {
    hintTextEl.textContent = currentPuzzle.hints[currentHintIndex];
    currentHintIndex++;
    hintUsed = true;
  } else {
    hintTextEl.textContent = "No more hints available for this difficulty.";
  }
});


  showSolutionBtn.addEventListener("click", () => {
    if (!currentPuzzle.fullSolution) return;
    solutionTextEl.textContent = currentPuzzle.fullSolution;
    solutionShown = true;
    showSolutionBtn.disabled = true;
  });

  resetBtn.addEventListener("click", () => {
    if (confirm("Reset XP and Level?")) resetProgress();
  });
});
