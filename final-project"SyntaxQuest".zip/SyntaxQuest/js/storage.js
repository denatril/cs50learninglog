// storage.js
const SQ_PREFIX = "sq_";

function sqSave(key, value) {
  try {
    const serialized = JSON.stringify(value);
    localStorage.setItem(SQ_PREFIX + key, serialized);
  } catch (err) {
    console.error("Storage save error:", err);
  }
}

function sqLoad(key, defaultValue = null) {
  try {
    const raw = localStorage.getItem(SQ_PREFIX + key);
    if (raw === null) return defaultValue;
    return JSON.parse(raw);
  } catch (err) {
    console.error("Storage load error:", err);
    return defaultValue;
  }
}

window.sqSave = sqSave;
window.sqLoad = sqLoad;

sq_achievements = {
  firstSolve: true,
  fiveSolves: true,
  tenSolves: true,
  firstHard: true,
  firstExpert: true,
  level10: true,
  level20: true,
}