// xp.js
const SQ_XP_KEY = "xp";

const SQ_XP_REWARDS = {
  easy: 5,
  hard: 10,
  expert: 20,
};

let sqCurrentXp = 0;

function sqInitXp() {
  const stored = sqLoad(SQ_XP_KEY, 0);
  sqCurrentXp = typeof stored === "number" ? stored : 0;
  return sqCurrentXp;
}

function sqGetXp() {
  return sqCurrentXp;
}

function sqSetXp(value) {
  sqCurrentXp = Number(value) || 0;
  sqSave(SQ_XP_KEY, sqCurrentXp);
  return sqCurrentXp;
}

function sqAddXp(amount) {
  const value = Number(amount) || 0;
  sqCurrentXp += value;
  sqSave(SQ_XP_KEY, sqCurrentXp);
  return sqCurrentXp;
}

function sqAddXpForDifficulty(difficulty) {
  const reward = SQ_XP_REWARDS[difficulty] || 0;
  return sqAddXp(reward);
}

function sqResetXp() {
  sqCurrentXp = 0;
  sqSave(SQ_XP_KEY, sqCurrentXp);
  return sqCurrentXp;
}

window.sqInitXp = sqInitXp;
window.sqGetXp = sqGetXp;
window.sqSetXp = sqSetXp;
window.sqAddXp = sqAddXp;
window.sqAddXpForDifficulty = sqAddXpForDifficulty;
window.sqResetXp = sqResetXp;