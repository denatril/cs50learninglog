// level.js
const SQ_LEVEL_KEY = "level";
const SQ_XP_PER_LEVEL = 100;

let sqCurrentLevel = 1;

function sqInitLevel() {
  const stored = sqLoad(SQ_LEVEL_KEY, 1);
  sqCurrentLevel = typeof stored === "number" ? stored : 1;
  return sqCurrentLevel;
}

function sqGetLevel() {
  return sqCurrentLevel;
}

function sqSetLevel(value) {
  sqCurrentLevel = Number(value) || 1;
  sqSave(SQ_LEVEL_KEY, sqCurrentLevel);
  return sqCurrentLevel;
}

function sqRecomputeLevelFromXp() {
  const xp = sqGetXp();
  const lvl = Math.floor(xp / SQ_XP_PER_LEVEL) + 1; // 0–99 → 1, 100–199 → 2 ...
  sqCurrentLevel = lvl;
  sqSave(SQ_LEVEL_KEY, sqCurrentLevel);
  return sqCurrentLevel;
}

window.sqInitLevel = sqInitLevel;
window.sqGetLevel = sqGetLevel;
window.sqSetLevel = sqSetLevel;
window.sqRecomputeLevelFromXp = sqRecomputeLevelFromXp;