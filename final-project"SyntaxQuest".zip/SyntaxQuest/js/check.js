// /js/check.js
// String-based answer normalization and comparison

function sqNormalizeCodeString(code) {
  if (code == null) return "";
  // Convert to string, trim, collapse whitespace
  return String(code)
    .trim()
    .replace(/\s+/g, " ");
}

function sqCheckAnswer(expected, userAnswer) {
  const normExpected = sqNormalizeCodeString(expected);
  const normUser = sqNormalizeCodeString(userAnswer);
  return normExpected === normUser;
}

window.sqNormalizeCodeString = sqNormalizeCodeString;
window.sqCheckAnswer = sqCheckAnswer;