// /js/templates.js
// Global puzzle packs for SyntaxQuest

const sqPuzzlePacks = {
  strings: [
    // ---------------- EASY 1 ----------------
    {
      id: "str-reverse-1",
      title: "Reverse 'hello'",
      description: "Reverse the string 'hello' and store it in result.",
      difficulty: "easy",
      starterCode: "",
      expectedSolution: "const result = 'hello'.split('').reverse().join('');",
      hints: [
        "Think: strings → array → reverse → string.",
        "You can split a string using split('').",
        "split('') turns 'hello' into ['h','e','l','l','o'].",
        "Arrays have a built-in reverse() method.",
        "After reversing, you need to convert it back to a string.",
        "join('') merges array characters with no separator.",
        "Combine split + reverse + join into one expression."
      ],
      fullSolution: "const result = 'hello'.split('').reverse().join('');"
    },

    // ---------------- EASY 2 ----------------
    {
      id: "str-length-1",
      title: "Length of 'SyntaxQuest'",
      description: "Store the length of 'SyntaxQuest' in result.",
      difficulty: "easy",
      starterCode: "",
      expectedSolution: "const result = 'SyntaxQuest'.length;",
      hints: [
        "Strings have a length property.",
        ".length returns a number.",
        "You don’t need parentheses.",
        "Just write the string then .length.",
        "Ensure correct spelling of 'SyntaxQuest'.",
        "The length counts all characters.",
        "Assign directly: const result = ..."
      ],
      fullSolution: "const result = 'SyntaxQuest'.length;"
    },

    // ---------------- EASY 3 ----------------
    {
      id: "str-upper-1",
      title: "Convert to Uppercase",
      description: "Convert 'quest' to uppercase.",
      difficulty: "easy",
      starterCode: "",
      expectedSolution: "const result = 'quest'.toUpperCase();",
      hints: [
        "Strings support toUpperCase().",
        "It returns a new string, does not mutate.",
        "Call toUpperCase() after the string.",
        "Ensure parentheses are present.",
        "Remember: JavaScript is case-sensitive.",
        "Store the returned value in result.",
        "This is a simple method call — nothing more needed."
      ],
      fullSolution: "const result = 'quest'.toUpperCase();"
    },

    // ---------------- HARD 1 ----------------
    {
      id: "str-remove-vowels",
      title: "Remove Vowels from 'javascript'",
      description: "Remove all vowels from the string 'javascript'.",
      difficulty: "hard",
      starterCode: "",
      expectedSolution:
        "const result = 'javascript'.split('').filter(c => !'aeiou'.includes(c)).join('');",
      hints: [
        "Think: remove characters → filter.",
        "Split the string to process each character.",
        "Check if a character is a vowel using includes().",
        "Filter out vowels, then join back."
      ],
      fullSolution:
        "const result = 'javascript'.split('').filter(c => !'aeiou'.includes(c)).join('');"
    },

    // ---------------- EXPERT 1 ----------------
    {
      id: "str-swapcase",
      title: "Swap Letter Case",
      description: "Swap the case of every letter in 'AbCdeF'.",
      difficulty: "expert",
      starterCode: "",
      expectedSolution:
        "const result = 'AbCdeF'.split('').map(c => c===c.toUpperCase()?c.toLowerCase():c.toUpperCase()).join('');",
      hints: [
        "Use map to transform each character.",
        "Compare character to its uppercase version."
      ],
      fullSolution:
        "const result = 'AbCdeF'.split('').map(c => c===c.toUpperCase()?c.toLowerCase():c.toUpperCase()).join('');"
    }
  ],

  arrays: [
    // ---------------- EASY 1 ----------------
    {
      id: "arr-first-1",
      title: "Get First Element",
      description: "Extract the first element of [10, 20, 30].",
      difficulty: "easy",
      starterCode: "",
      expectedSolution: "const result = [10, 20, 30][0];",
      hints: [
        "Array indexes start at 0.",
        "[0] accesses the first element.",
        "No loops needed.",
        "Use direct indexing.",
        "Ensure correct array syntax.",
        "The result should be 10.",
        "Assign it directly to result."
      ],
      fullSolution: "const result = [10, 20, 30][0];"
    },

    // ---------------- EASY 2 ----------------
    {
      id: "arr-length-1",
      title: "Array Length",
      description: "Store the length of [5, 6, 7, 8].",
      difficulty: "easy",
      starterCode: "",
      expectedSolution: "const result = [5,6,7,8].length;",
      hints: [
        "Arrays have a length property.",
        ".length returns the number of items.",
        "Same as string length property.",
        "No parentheses needed.",
        "Ensure correct array syntax.",
        "The result should be 4.",
        "Assign to result directly."
      ],
      fullSolution: "const result = [5,6,7,8].length;"
    },

    // ---------------- HARD 1 ----------------
    {
      id: "arr-sum-1",
      title: "Sum an Array",
      description: "Sum the values in [1, 2, 3, 4].",
      difficulty: "hard",
      starterCode: "",
      expectedSolution:
        "const result = [1,2,3,4].reduce((a,b)=>a+b,0);",
      hints: [
        "Use reduce to accumulate values.",
        "Pass a function that adds numbers.",
        "Start from 0.",
        "Return final accumulator."
      ],
      fullSolution:
        "const result = [1,2,3,4].reduce((a,b)=>a+b,0);"
    },

    // ---------------- HARD 2 ----------------
    {
      id: "arr-even-1",
      title: "Filter Even Numbers",
      description: "Filter even numbers from [1,2,3,4,5,6].",
      difficulty: "hard",
      starterCode: "",
      expectedSolution:
        "const result = [1,2,3,4,5,6].filter(n=>n%2===0);",
      hints: [
        "Use filter() to keep valid values.",
        "Even numbers satisfy n % 2 === 0.",
        "Filter returns a new array.",
        "No need for loops."
      ],
      fullSolution:
        "const result = [1,2,3,4,5,6].filter(n=>n%2===0);"
    },

    // ---------------- EXPERT 1 ----------------
    {
      id: "arr-flatten-1",
      title: "Flatten Nested Arrays",
      description: "Flatten [[1],[2],[3]] into [1,2,3].",
      difficulty: "expert",
      starterCode: "",
      expectedSolution:
        "const result = [[1],[2],[3]].flat();",
      hints: [
        "flat() removes one level of nesting.",
        "Call flat() directly on array."
      ],
      fullSolution:
        "const result = [[1],[2],[3]].flat();"
    }
  ]
};

// Expose globally
window.sqPuzzlePacks = sqPuzzlePacks;
