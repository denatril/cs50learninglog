// background.js
// Service worker for SyntaxQuest extension

chrome.runtime.onInstalled.addListener(() => {
  console.log('SyntaxQuest extension installed');
});

chrome.runtime.onStartup.addListener(() => {
  console.log('SyntaxQuest extension started');
});